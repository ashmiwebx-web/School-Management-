import React, { useCallback, useEffect, useMemo, useState } from "react";
import { FiX } from "react-icons/fi";

import CommonTable from "../../components/Table/CommonTable";
import Pagination from "../../components/Pagination/Pagination";
import { EVENTS, PAGE_SIZE, classNames } from "../../constants/theme";
import { getAcademicLevels } from "../../services/academicLevelService";
import { getSubjects } from "../../services/subjectService";
import {
  createAlloteSubject,
  getAlloteSubjects,
  updateAlloteSubject,
} from "../../services/alloteSubjectService";
import { showError, showSuccess } from "../../components/Toast/AppToast";

const emptyForm = {
  academicLevelId: "",
  subjectIds: [],
};

const getSubjectNames = (item) =>
  Array.isArray(item?.subjects)
    ? item.subjects.map((subject) => subject.subjectName).filter(Boolean)
    : [];

export default function AlloteSubject() {
  const [rows, setRows] = useState([]);
  const [levels, setLevels] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [open, setOpen] = useState(false);
  const [viewOpen, setViewOpen] = useState(false);
  const [editData, setEditData] = useState(null);
  const [viewData, setViewData] = useState(null);
  const [page, setPage] = useState(1);

  const loadData = useCallback(async (silent = false) => {
    try {
      const [alloteData, levelData, subjectData] = await Promise.all([
        getAlloteSubjects(),
        getAcademicLevels(),
        getSubjects(),
      ]);

      setRows(Array.isArray(alloteData) ? alloteData : []);
      setLevels(Array.isArray(levelData) ? levelData : []);
      setSubjects(Array.isArray(subjectData) ? subjectData : []);
    } catch (error) {
      if (!silent) showError(error.message);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  useEffect(() => {
    const refreshPage = () => loadData(true);

    window.addEventListener(EVENTS.subjectsUpdated, refreshPage);
    window.addEventListener(EVENTS.alloteSubjectsUpdated, refreshPage);
    window.addEventListener("focus", refreshPage);

    return () => {
      window.removeEventListener(EVENTS.subjectsUpdated, refreshPage);
      window.removeEventListener(EVENTS.alloteSubjectsUpdated, refreshPage);
      window.removeEventListener("focus", refreshPage);
    };
  }, [loadData]);

  const totalPages = Math.ceil(rows.length / PAGE_SIZE) || 1;

  const paginatedRows = useMemo(() => {
    const start = (page - 1) * PAGE_SIZE;
    return rows.slice(start, start + PAGE_SIZE);
  }, [rows, page]);

  const openAdd = () => {
    setEditData(null);
    setForm(emptyForm);
    setOpen(true);
  };

  const openEdit = (item) => {
    setEditData(item);
    setForm({
      academicLevelId: item.academicLevelId || "",
      subjectIds: Array.isArray(item.subjects)
        ? item.subjects.map((subject) => Number(subject.id)).filter(Boolean)
        : [],
    });
    setOpen(true);
  };

  const openView = (item) => {
    setViewData(item);
    setViewOpen(true);
  };

  const closeModal = () => {
    setOpen(false);
    setEditData(null);
    setForm(emptyForm);
  };

  const toggleSubject = (id) => {
    const subjectId = Number(id);

    setForm((prev) => {
      const exists = prev.subjectIds.includes(subjectId);

      return {
        ...prev,
        subjectIds: exists
          ? prev.subjectIds.filter((value) => value !== subjectId)
          : [...prev.subjectIds, subjectId],
      };
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.academicLevelId) {
      showError("Select Academic Level");
      return;
    }

    if (form.subjectIds.length === 0) {
      showError("Select at least one subject");
      return;
    }

    try {
      if (editData) {
        await updateAlloteSubject(editData.id, form);
        showSuccess("Allote Subject updated successfully");
      } else {
        await createAlloteSubject(form);
        showSuccess("Allote Subject added successfully");
      }

      closeModal();
      setPage(1);
      await loadData(true);
      window.dispatchEvent(new Event(EVENTS.alloteSubjectsUpdated));
    } catch (error) {
      showError(error.message);
    }
  };

  return (
    <div className={classNames.page}>
      <div className={classNames.card}>
        <div className={classNames.cardHeader}>
          <div>
            <h2 className={classNames.title}>Allote Subject</h2>
            <p className={classNames.subtitle}>
              Manage academic level wise subject allocation
            </p>
          </div>

          <button
            type="button"
            onClick={openAdd}
            className={classNames.primaryButton}
          >
            Allote Subject
          </button>
        </div>

        <CommonTable
          data={paginatedRows}
          serialStart={(page - 1) * PAGE_SIZE}
          emptyText="No allotted subjects found"
          columns={[
            {
              key: "academicLevel",
              title: "Academic Type",
              align: "center",
              bold: true,
              width: "30%",
            },
            {
              key: "noOfSubjects",
              title: "No. Of Subjects",
              align: "center",
              bold: true,
              width: "20%",
            },
            {
              key: "details",
              title: "Details",
              align: "center",
              width: "35%",
              render: (item) => {
                const names = getSubjectNames(item);
                if (names.length === 0) return "-";

                const firstTwo = names.slice(0, 2).join(", ");
                const remaining = names.length - 2;

                return remaining > 0
                  ? `${firstTwo}... +${remaining}`
                  : firstTwo;
              },
            },
          ]}
          actionWidth="15%"
          snoWidth="10%"
          onView={openView}
          onEdit={openEdit}
        />

        <Pagination
          currentPage={page}
          totalPages={totalPages}
          onPageChange={setPage}
        />
      </div>

      {open && (
        <div className={classNames.modalOverlay}>
          <div className="w-[560px] rounded-[var(--radius)] bg-[var(--color-surface)] shadow-xl">
            <div className={classNames.modalHeader}>
              <h2 className="text-[20px] font-bold text-[var(--color-text)]">
                {editData ? "Edit Allote Subject" : "Allote Subject"}
              </h2>

              <button
                type="button"
                onClick={closeModal}
                className="flex h-[34px] w-[34px] cursor-pointer items-center justify-center rounded-full bg-[#f1f3f8] text-[var(--color-text)] hover:bg-[#e7ebf3]"
              >
                <FiX />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6">
              <label className={classNames.formLabel}>
                Select Academic Level
              </label>

              <select
                value={form.academicLevelId}
                onChange={(e) =>
                  setForm((prev) => ({
                    ...prev,
                    academicLevelId: e.target.value,
                  }))
                }
                className={`${classNames.input} mb-5`}
              >
                <option value="">Select Academic Level</option>
                {levels.map((level) => (
                  <option key={level.id} value={level.id}>
                    {level.levelName}
                  </option>
                ))}
              </select>

              <div className="mb-2 flex items-center justify-between">
                <h3 className="text-[15px] font-bold text-[var(--color-text)]">
                  Subjects
                </h3>

                <span className="text-[13px] font-semibold text-[var(--color-primary)]">
                  Selected: {form.subjectIds.length}
                </span>
              </div>

              <div className="max-h-[240px] overflow-y-auto rounded-[8px] border border-[var(--color-border)] p-3">
                {subjects.length === 0 ? (
                  <div className="p-4 text-center text-[14px] text-[var(--color-textMuted)]">
                    No subjects found
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-3">
                    {subjects.map((subject) => (
                      <label
                        key={subject.id}
                        className="flex h-[38px] cursor-pointer items-center gap-2 rounded-[6px] border border-[var(--color-borderSoft)] bg-white px-3 hover:bg-[var(--color-surfaceSoft)]"
                      >
                        <input
                          type="checkbox"
                          checked={form.subjectIds.includes(Number(subject.id))}
                          onChange={() => toggleSubject(subject.id)}
                          className="h-[15px] w-[15px] cursor-pointer accent-[#506ee4]"
                        />

                        <span className="truncate text-[13px] font-semibold text-[var(--color-text)]">
                          {subject.subjectName}
                        </span>
                      </label>
                    ))}
                  </div>
                )}
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={closeModal}
                  className={classNames.secondaryButton}
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="h-[42px] cursor-pointer rounded-[6px] bg-[var(--color-primary)] px-5 text-[14px] font-semibold text-white hover:bg-[var(--color-primaryHover)]"
                >
                  {editData ? "Update" : "Save"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {viewOpen && viewData && (
        <div className={classNames.modalOverlay}>
          <div className="w-[560px] rounded-[var(--radius)] bg-[var(--color-surface)] shadow-xl">
            <div className={classNames.modalHeader}>
              <h2 className="text-[20px] font-bold text-[var(--color-text)]">
                Allote Subject Details
              </h2>

              <button
                type="button"
                onClick={() => setViewOpen(false)}
                className="flex h-[34px] w-[34px] cursor-pointer items-center justify-center rounded-full bg-[#f1f3f8] text-[var(--color-text)] hover:bg-[#e7ebf3]"
              >
                <FiX />
              </button>
            </div>

            <div className="p-6">
              <p className="mb-4 text-[15px] font-bold text-[var(--color-text)]">
                Academic Type: {viewData.academicLevel || "-"}
              </p>

              <div className="rounded-[8px] border border-[var(--color-border)]">
                {Array.isArray(viewData.subjects) &&
                viewData.subjects.length > 0 ? (
                  viewData.subjects.map((subject, index) => (
                    <div
                      key={subject.id || index}
                      className="flex h-[46px] items-center justify-between border-b border-[var(--color-borderSoft)] px-4 last:border-b-0"
                    >
                      <span className="text-[14px] font-semibold text-[var(--color-text)]">
                        {index + 1}. {subject.subjectName}
                      </span>

                      <span className="text-[13px] font-semibold text-[var(--color-primary)]">
                        {subject.subjectCode || "-"}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="p-4 text-center text-[14px] text-[var(--color-textMuted)]">
                    No subjects found
                  </div>
                )}
              </div>

              <div className="mt-5 flex justify-end">
                <button
                  type="button"
                  onClick={() => setViewOpen(false)}
                  className="h-[42px] cursor-pointer rounded-[6px] bg-[var(--color-primary)] px-5 text-[14px] font-semibold text-white hover:bg-[var(--color-primaryHover)]"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}