import React from "react";
import { FiEdit2, FiEye } from "react-icons/fi";

const getAlignClass = (align = "center") => {
  if (align === "left") return "text-left";
  if (align === "right") return "text-right";
  return "text-center";
};

const getWidthStyle = (width) => (width ? { width } : undefined);

const getCellValue = (item, col) => {
  if (typeof col.render === "function") return col.render(item);

  const value = item?.[col.key];
  return value === undefined || value === null || value === "" ? "-" : value;
};

export default function CommonTable({
  data = [],
  columns = [],
  serialStart = 0,
  onEdit = null,
  onView = null,
  emptyText = "No data found",
  actionTitle = "Action",
  snoWidth = "80px",
  actionWidth = "100px",
}) {
  const showAction = Boolean(onEdit || onView);

  return (
    <div className="w-full overflow-x-auto">
      <table className="w-full table-fixed border-collapse">
        <thead>
          <tr className="h-[40px] bg-[var(--color-tableHead)]">
            <th
              style={{ width: snoWidth }}
              className="px-3 text-center text-[14px] font-semibold text-[var(--color-textBody)]"
            >
              S.No
            </th>

            {columns.map((col) => (
              <th
                key={col.key}
                style={getWidthStyle(col.width)}
                className={`px-3 text-[14px] font-semibold text-[var(--color-textBody)] ${getAlignClass(
                  col.align
                )}`}
              >
                {col.title}
              </th>
            ))}

            {showAction && (
              <th
                style={{ width: actionWidth }}
                className="px-3 text-center text-[14px] font-semibold text-[var(--color-textBody)]"
              >
                {actionTitle}
              </th>
            )}
          </tr>
        </thead>

        <tbody>
          {data.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length + (showAction ? 2 : 1)}
                className="h-[62px] text-center text-[13px] text-[var(--color-textMuted)]"
              >
                {emptyText}
              </td>
            </tr>
          ) : (
            data.map((item, index) => (
              <tr
                key={item.id || item._id || index}
                className="h-[48px] border-b border-[var(--color-borderSoft)] bg-[var(--color-surface)] hover:bg-[var(--color-surfaceSoft)]"
              >
                <td className="px-3 text-center text-[13px] font-medium text-[var(--color-textBody)]">
                  {serialStart + index + 1}
                </td>

                {columns.map((col) => {
                  const value = getCellValue(item, col);

                  return (
                    <td
                      key={col.key}
                      className={`truncate px-3 text-[13px] ${getAlignClass(
                        col.align
                      )} ${
                        col.blue
                          ? "font-semibold text-[var(--color-blue)]"
                          : col.bold
                          ? "font-semibold text-[var(--color-textBody)]"
                          : "text-[var(--color-textBody)]"
                      }`}
                    >
                      {col.badge ? (
                        <span className="inline-flex min-w-[78px] justify-center rounded bg-[var(--color-blueSoft)] px-2 py-[3px] font-semibold text-[var(--color-primary)]">
                          {value}
                        </span>
                      ) : (
                        value
                      )}
                    </td>
                  );
                })}

                {showAction && (
                  <td className="px-3 text-center">
                    <div className="flex items-center justify-center gap-2">
                      {onView && (
                        <button
                          type="button"
                          onClick={() => onView(item)}
                          className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded bg-[var(--color-blueSoft)] text-[var(--color-blue)] hover:bg-[#dfe6ff]"
                          title="View"
                        >
                          <FiEye size={13} />
                        </button>
                      )}

                      {onEdit && (
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="flex h-[28px] w-[28px] cursor-pointer items-center justify-center rounded bg-[var(--color-blueSoft)] text-[var(--color-blue)] hover:bg-[#dfe6ff]"
                          title="Edit"
                        >
                          <FiEdit2 size={13} />
                        </button>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}
