import React from "react";
import { FiPlusCircle } from "react-icons/fi";
import CommonButton from "./CommonButton";

export default function PrimaryButton({
  children,
  onClick,
  type = "button",
  className = "",
  disabled = false,
  variant,
  size,
}) {
  const text = typeof children === "string" ? children.trim() : "";
  const isAddButton = text.toLowerCase().startsWith("add");

  return (
    <CommonButton
      type={type}
      onClick={onClick}
      disabled={disabled}
      variant={variant || (isAddButton ? "add" : "primary")}
      size={size || (isAddButton ? "lg" : "md")}
      className={`${isAddButton ? "font-bold" : ""} ${className}`}
    >
      {isAddButton && <FiPlusCircle className="text-[18px]" />}
      {children}
    </CommonButton>
  );
}
