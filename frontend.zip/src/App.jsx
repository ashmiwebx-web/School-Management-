import React from "react";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";

import Sidebar from "./components/Sidebar/Sidebar";
import Navbar from "./components/Navbar/Navbar";
import AppToast from "./components/Toast/AppToast";

import BlocksClassRooms from "./pages/BlocksClassRooms/BlocksClassRooms";
import StandardSections from "./pages/StandardSections/StandardSections";
import ClassAllocation from "./pages/ClassAllocation/ClassAllocation";
import AddStudent from "./pages/Students/AddStudent";
import StudentList from "./pages/Students/StudentList";
import StudentView from "./pages/Students/StudentView";

export default function App() {
  return (
    <BrowserRouter>
      <AppToast />

      <div className="min-h-screen bg-[#f6f7fb]">
        <Sidebar />

        <div className="ml-[260px] min-h-screen">
          <Navbar />

          <main className="p-6">
            <Routes>
              <Route path="/" element={<Navigate to="/student-list" replace />} />

              <Route path="/student-list" element={<StudentList />} />
              <Route path="/add-student" element={<AddStudent />} />
              <Route path="/edit-student/:id" element={<AddStudent />} />
              <Route path="/student-view/:id" element={<StudentView />} />

              <Route path="/blocks-classrooms" element={<BlocksClassRooms />} />
              <Route path="/standard-sections" element={<StandardSections />} />
              <Route path="/class-allocation" element={<ClassAllocation />} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}