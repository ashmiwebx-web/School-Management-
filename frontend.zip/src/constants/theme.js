export const API_URL =
  import.meta.env.VITE_API_URL || "http://localhost:5000";

export const API = API_URL;

export const PAGE_SIZE = 5;

export const EVENTS = {
  blocksUpdated: "school:blocks-updated",
  classRoomsUpdated: "school:classrooms-updated",
  standardsUpdated: "school:standards-updated",
  sectionsUpdated: "school:sections-updated",
};