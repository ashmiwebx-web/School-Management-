const API = import.meta.env.VITE_API_URL || "http://localhost:5000";

const parseResponse = async (res) => {
  const data = await res.json();

  if (!res.ok) {
    throw new Error(data.message || "Request failed");
  }

  return data;
};

export const getStudents = async () => {
  const res = await fetch(`${API}/api/students`);
  return parseResponse(res);
};

export const getStudentById = async (id) => {
  const res = await fetch(`${API}/api/students/${id}`);
  return parseResponse(res);
};

export const getNextStudentIds = async () => {
  const res = await fetch(`${API}/api/students/next-ids`);
  return parseResponse(res);
};

export const createStudent = async (payload) => {
  const res = await fetch(`${API}/api/students`, {
    method: "POST",
    body: payload,
  });

  return parseResponse(res);
};

export const updateStudent = async (id, payload) => {
  const res = await fetch(`${API}/api/students/${id}`, {
    method: "PUT",
    body: payload,
  });

  return parseResponse(res);
};

export const deleteStudent = async (id) => {
  const res = await fetch(`${API}/api/students/${id}`, {
    method: "DELETE",
  });

  return parseResponse(res);
};