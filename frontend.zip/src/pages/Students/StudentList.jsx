import React, { useEffect, useMemo, useState } from "react";
import { FiEdit2, FiEye } from "react-icons/fi";
import { useNavigate } from "react-router-dom";

import Pagination from "../../components/Pagination/Pagination";
import PrimaryButton from "../../components/Buttons/PrimaryButton";
import { PAGE_SIZE } from "../../constants/theme";
import { getStudents } from "../../services/studentService";
import { showError } from "../../components/Toast/AppToast";

export default function StudentList() {
  const navigate = useNavigate();
  const [students, setStudents] = useState([]);
  const [page, setPage] = useState(1);

  const fetchStudents = async () => {
    try {
      const data = await getStudents();
      setStudents(Array.isArray(data) ? data : []);
    } catch (error) {
      showError(error.message);
    }
  };

  useEffect(() => {
    fetchStudents();
  }, []);

  const totalPages = Math.ceil(students.length / PAGE_SIZE) || 1;
const formatDate = (date) => {
  if (!date) return "-";

  const d = new Date(date);

  const day = String(d.getDate()).padStart(2, "0");
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const year = d.getFullYear();

  return `${day}/${month}/${year}`;
};
  const paginated = useMemo(() => {
    const start = (page - 1) * PAGE_SIZE;
    return students.slice(start, start + PAGE_SIZE);
  }, [students, page]);

  return (
    <div className="mt-4 rounded-[8px] border border-[#e5e9f2] bg-white">
      <div className="flex items-center justify-between border-b border-[#e5e9f2] p-5">
        <div>
          <h1 className="text-[22px] font-bold text-[#202c4b]">
            Student List
          </h1>
          <p className="mt-1 text-[14px] text-[#64748b]">
            Manage student details
          </p>
        </div>

        <PrimaryButton onClick={() => navigate("/add-student")}>
          Add Student
        </PrimaryButton>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[1100px] border-collapse">
          <thead>
            <tr className="h-[62px] bg-[#f4f6fb] text-center text-[14px] font-semibold text-[#061b49]">
              <th className="px-5 text-center">S.No</th>
              <th className="px-5 text-center">Admission Number</th>
              <th className="px-5 text-center">Name</th>
              <th className="px-5 text-center">Class</th>
              <th className="px-5 text-center">Section</th>
              <th className="px-5 text-center">Gender</th>
              <th className="px-5 text-center">Status</th>
              <th className="px-5 text-center">Date of Join</th>
              <th className="px-5 text-center">DOB</th>
              <th className="px-5 text-center">Action</th>
            </tr>
          </thead>

          <tbody>
            {paginated.length === 0 ? (
              <tr>
                <td
                  colSpan={10}
                  className="h-[90px] text-center text-[14px] text-[#64748b]"
                >
                  No students found
                </td>
              </tr>
            ) : (
              paginated.map((item, index) => (
                <tr
                  key={item.id}
                  className="h-[74px] border-b border-[#eef1f6] text-center text-[14px] text-[#061b49]"
                >
                  <td className="px-5 text-center">
                    {(page - 1) * PAGE_SIZE + index + 1}
                  </td>

                  <td className="px-5 text-center font-medium text-[#3158ff]">
                    {item.admissionNumber || "-"}
                  </td>

                  <td className="px-5 text-left font-semibold">
                    {item.name || "-"}
                  </td>

                  <td className="px-5 text-left">
                    {item.className || "-"}
                  </td>

                  <td className="px-5 text-center">
                    {item.sectionName || "-"}
                  </td>

                  <td className="px-5 text-center">
                    {item.gender || "-"}
                  </td>

                  <td className="px-5 text-center font-medium text-[#3158ff]">
                    {item.status || "-"}
                  </td>

                <td className="px-5 text-center">
  {formatDate(item.admissionDate)}
</td>

<td className="px-5 text-center">
  {formatDate(item.dateOfBirth)}
</td>
                  <td className="px-5 text-center">
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => navigate(`/student-view/${item.id}`)}
                        className="flex h-[34px] w-[34px] cursor-pointer items-center justify-center rounded-[6px] bg-[#eef3ff] text-[#506ee4]"
                      >
                        <FiEye size={16} />
                      </button>

                      <button
                        type="button"
                        onClick={() => navigate(`/edit-student/${item.id}`)}
                        className="flex h-[34px] w-[34px] cursor-pointer items-center justify-center rounded-[6px] bg-[#eef3ff] text-[#506ee4]"
                      >
                        <FiEdit2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <Pagination
        currentPage={page}
        totalPages={totalPages}
        onPageChange={setPage}
      />
    </div>
  );
}