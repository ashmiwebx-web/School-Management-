import React from "react";
import FormSelect from "../../../components/Inputs/FormSelect";

function Card({ title, children }) {
  return (
    <section className="rounded-[8px] border border-[#e5e9f2] bg-white">
      <div className="bg-[#e9edf5] px-6 py-4">
        <h2 className="text-[20px] font-bold text-[#061b49]">{title}</h2>
      </div>
      <div className="p-6">{children}</div>
    </section>
  );
}

export default function SiblingInfo({ formData, updateField }) {
  return (
    <Card title="Siblings">
      <h3 className="mb-4 font-semibold">Sibling Info</h3>

      <div className="mb-5 flex gap-5">
        <span>Is Sibling studying in same school</span>
        {["Yes", "No"].map((x) => (
          <label key={x} className="flex items-center gap-2">
            <input type="radio" checked={formData.siblingInSchool === x} onChange={() => updateField("siblingInSchool", x)} />
            {x}
          </label>
        ))}
      </div>

      {formData.siblingInSchool === "Yes" && (
        <>
          <div className="grid grid-cols-1 gap-5 md:grid-cols-4">
            <FormSelect label="Name" placeholder="Select" options={[]} />
            <FormSelect label="Roll No" placeholder="Select" options={[]} />
            <FormSelect label="Admission No" placeholder="Select" options={[]} />
            <FormSelect label="Class" placeholder="Select" options={[]} />
          </div>

          <button
            type="button"
            className="mt-5 h-[42px] rounded-[6px] bg-[#506ee4] px-5 text-white"
          >
            Add New
          </button>
        </>
      )}
    </Card>
  );
}