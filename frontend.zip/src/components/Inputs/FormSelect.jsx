import React from "react";

export default function FormSelect({
  label,
  value,
  onChange,
  options = [],
  placeholder = "Select",
  required = false,
}) {
  return (
    <div>
      <label className="mb-2 block text-[14px] font-medium text-[#202c4b]">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </label>

      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-[40px] w-full rounded-[6px] border border-[#e5e9f2] px-3 text-[14px] outline-none focus:border-[#506ee4]"
      >
        <option value="">{placeholder}</option>

        {options.map((item) => (
          <option key={item.value} value={item.value}>
            {item.label}
          </option>
        ))}
      </select>
    </div>
  );
}