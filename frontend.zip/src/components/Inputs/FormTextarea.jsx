import React from "react";

export default function FormTextarea({
  label,
  value = "",
  onChange = () => {},
  placeholder = "",
  maxLength = 50,
  rows = 4,
}) {
  const handleChange = (e) => {
    let val = e.target.value;

    if (maxLength) {
      val = val.slice(0, maxLength);
    }

    onChange(val);
  };

  return (
    <div>
      <label className="mb-2 block text-[14px] font-semibold text-[#061b49]">
        {label}
      </label>

      <textarea
        value={value}
        placeholder={placeholder}
        rows={rows}
        maxLength={maxLength}
        onChange={handleChange}
        className="w-full resize-none rounded-[6px] border border-[#e5e9f2] px-3 py-3 text-[14px] outline-none focus:border-[#506ee4]"
      />

      <p className="mt-1 text-right text-[12px] text-[#64748b]">
        {value.length}/{maxLength}
      </p>
    </div>
  );
}