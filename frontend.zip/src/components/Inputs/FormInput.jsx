import React from "react";

export default function FormInput({
  label,
  value = "",
  onChange = () => {},
  placeholder = "",
  type = "text",
  readOnly = false,
  maxLength = 20,
  numbersOnly = false,
  required = false,
}) {
  const handleChange = (e) => {
    let val = e.target.value;

    if (numbersOnly) val = val.replace(/\D/g, "");
    if (maxLength) val = val.slice(0, maxLength);

    onChange(val);
  };

  return (
    <div>
      <label className="mb-2 block text-[14px] font-semibold text-[#061b49]">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </label>

      <input
        type={type}
        value={value}
        readOnly={readOnly}
        placeholder={placeholder}
        onChange={handleChange}
        className="h-[44px] w-full rounded-[6px] border border-[#e5e9f2] px-3 text-[14px] outline-none focus:border-[#506ee4]"
      />
    </div>
  );
}