import React from "react";
import { FiEdit2, FiEye } from "react-icons/fi";

const getAlignClass = (align = "center") => {
  if (align === "left") return "text-left";
  if (align === "right") return "text-right";
  return "text-center";
};

export default function CommonTable({
  data = [],
  columns = [],
  serialStart = 0,
  onEdit = null,
  onView = null,
  emptyText = "No data found",
}) {
  const showAction = onEdit || onView;

  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse">
        <thead>
          <tr className="h-[58px] bg-[#f5f7fb]">
            <th className="px-4 text-center text-[13px] font-semibold text-[#34415d]">
              S.No
            </th>

            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 text-center text-[13px] font-semibold text-[#34415d]"
              >
                {col.title}
              </th>
            ))}

            {showAction && (
              <th className="px-4 text-center text-[13px] font-semibold text-[#34415d]">
                Action
              </th>
            )}
          </tr>
        </thead>

        <tbody>
          {data.length === 0 ? (
            <tr>
              <td
                colSpan={columns.length + (showAction ? 2 : 1)}
                className="h-[86px] text-center text-[14px] text-[#64748b]"
              >
                {emptyText}
              </td>
            </tr>
          ) : (
            data.map((item, index) => (
              <tr
                key={item.id || index}
                className="h-[64px] border-b border-[#eef1f6] bg-white"
              >
                <td className="px-4 text-center text-[14px] text-[#34415d]">
                  {serialStart + index + 1}
                </td>

                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={`px-4 text-[14px] ${getAlignClass(
                      col.align
                    )} ${
                      col.blue
                        ? "font-semibold text-[#3158ff]"
                        : col.bold
                        ? "font-semibold text-[#202c4b]"
                        : "text-[#34415d]"
                    }`}
                  >
                    {item[col.key] || "-"}
                  </td>
                ))}

                {showAction && (
                  <td className="px-4 text-center">
                    <div className="flex items-center justify-center gap-2">
                      {onView && (
                        <button
                          type="button"
                          onClick={() => onView(item)}
                          className="flex h-[34px] w-[34px] cursor-pointer items-center justify-center rounded bg-[#eef2ff] text-[#3158ff] hover:bg-[#dfe6ff]"
                          title="View"
                        >
                          <FiEye size={15} />
                        </button>
                      )}

                      {onEdit && (
                        <button
                          type="button"
                          onClick={() => onEdit(item)}
                          className="flex h-[34px] w-[34px] cursor-pointer items-center justify-center rounded bg-[#eef2ff] text-[#3158ff] hover:bg-[#dfe6ff]"
                          title="Edit"
                        >
                          <FiEdit2 size={15} />
                        </button>
                      )}
                    </div>
                  </td>
                )}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}