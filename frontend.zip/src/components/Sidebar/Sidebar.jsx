import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { FiBookOpen, FiGrid, FiLayers, FiUsers } from "react-icons/fi";

const menuItems = [
  {
    label: "Students",
    to: "/student-list",
    icon: FiUsers,
    activePaths: ["/student-list", "/add-student", "/edit-student", "/student-view"],
  },
  {
    label: "Blocks & Class Rooms",
    to: "/blocks-classrooms",
    icon: FiGrid,
    activePaths: ["/blocks-classrooms", "/blocks", "/classrooms"],
  },
  {
    label: "Class Allocation",
    to: "/class-allocation",
    icon: FiLayers,
    activePaths: ["/class-allocation"],
  },
  {
    label: "Standard & Sections",
    to: "/standard-sections",
    icon: FiBookOpen,
    activePaths: ["/standard-sections", "/generate-rollno", "/combined-std"],
  },
];

export default function Sidebar() {
  const location = useLocation();

  const isMenuActive = (item) =>
    item.activePaths.some((path) => location.pathname.startsWith(path));

  const menuClass = (active) =>
    `flex h-[44px] items-center gap-3 rounded-[6px] px-3 text-[14px] font-medium transition-all ${
      active
        ? "bg-[#eef2ff] text-[#3158ff]"
        : "text-[#34415d] hover:bg-[#f5f7ff] hover:text-[#3158ff]"
    }`;

  return (
    <aside className="fixed left-0 top-0 z-[1000] h-screen w-[260px] border-r border-[#e5e9f2] bg-white">
      <div className="flex h-[64px] items-center border-b border-[#e5e9f2] px-5">
        <h1 className="text-[20px] font-bold text-[#061b49]">School</h1>
      </div>

      <nav className="space-y-2 p-3">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const active = isMenuActive(item);

          return (
            <NavLink key={item.label} to={item.to} className={() => menuClass(active)}>
              <Icon size={18} />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>
    </aside>
  );
}
