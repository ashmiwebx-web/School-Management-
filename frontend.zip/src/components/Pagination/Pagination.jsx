import React from "react";

export default function Pagination({ currentPage, totalPages, onPageChange }) {
  if (totalPages <= 1) return null;

  return (
    <div className="flex items-center justify-end gap-2 border-t border-[#e5e9f2] p-4">
      <button
        type="button"
        disabled={currentPage === 1}
        onClick={() => onPageChange(currentPage - 1)}
        className="h-[34px] rounded border border-[#e5e9f2] px-3 text-[13px] disabled:opacity-50"
      >
        Prev
      </button>

      <span className="text-[13px] text-[#34415d]">
        Page {currentPage} of {totalPages}
      </span>

      <button
        type="button"
        disabled={currentPage === totalPages}
        onClick={() => onPageChange(currentPage + 1)}
        className="h-[34px] rounded border border-[#e5e9f2] px-3 text-[13px] disabled:opacity-50"
      >
        Next
      </button>
    </div>
  );
}