import React from "react";
import { FiX } from "react-icons/fi";

export default function CommonModal({
  open,
  title,
  children,
  onClose,
  onSave,
  saveText = "Save",
  width = "max-w-[520px]",
  showFooter = true,
}) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 px-4">
      <div className={`w-full ${width} rounded-[8px] bg-white shadow-xl`}>
        <div className="flex h-[58px] shrink-0 items-center justify-between border-b border-[#e5e9f2] px-5">
          <h2 className="text-[18px] font-semibold text-[#202c4b]">{title}</h2>

          <button
            type="button"
            onClick={onClose}
            className="flex h-[32px] w-[32px] items-center justify-center rounded hover:bg-[#f5f7ff]"
          >
            <FiX size={18} />
          </button>
        </div>

    <div className="max-h-[70vh] overflow-y-auto p-5">
  {children}
</div>
        {showFooter && (
          <div className="flex h-[68px] shrink-0 justify-end gap-3 border-t border-[#e5e9f2] px-5 py-4">
            <button
              type="button"
              onClick={onClose}
              className="h-[40px] rounded-[6px] border border-[#e5e9f2] px-5 text-[14px] font-semibold text-[#34415d]"
            >
              Cancel
            </button>

            {onSave && (
              <button
                type="button"
                onClick={onSave}
                className="h-[40px] rounded-[6px] bg-[#506ee4] px-5 text-[14px] font-semibold text-white"
              >
                {saveText}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}