import React from "react";

export default function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="rounded-[8px] border border-[#e5e9f2] bg-white p-6">
      <h1 className="text-[22px] font-bold text-[#202c4b]">{title}</h1>

      {subtitle && (
        <p className="mt-1 text-[14px] text-[#64748b]">{subtitle}</p>
      )}

      {actions && <div className="mt-6 flex flex-wrap gap-3">{actions}</div>}
    </div>
  );
}
